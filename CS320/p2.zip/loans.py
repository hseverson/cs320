import json
from zipfile import ZipFile
from io import TextIOWrapper
import csv

class Applicant:
    def __init__(self, age, race):
        self.age = age
        self.race = set()
        for r in race:
            if r in race_lookup:
                self.race.add(race_lookup[r])
    def __repr__(self):
        return f"Applicant({repr(self.age)}, {repr(list(self.race))})"
    def lower_age(self):
        return int(self.age.replace("<","").replace(">","").split("-")[0])
    def __lt__(self, other):
        return self.lower_age() < other.lower_age()

race_lookup = {
    "1": "American Indian or Alaska Native",
    "2": "Asian",
    "21": "Asian Indian",
    "22": "Chinese",
    "23": "Filipino",
    "24": "Japanese",
    "25": "Korean",
    "26": "Vietnamese",
    "27": "Other Asian",
    "3": "Black or African American",
    "4": "Native Hawaiian or Other Pacific Islander",
    "41": "Native Hawaiian",
    "42": "Guamanian or Chamorro",
    "43": "Samoan",
    "44": "Other Pacific Islander",
    "5": "White",
}

class Loan:
    def __init__(self, fields):        
        try:
            self.loan_amount = float(fields["loan_amount"])
        except ValueError:
            self.loan_amount = -1
        try:
            self.property_value = float(fields["property_value"])
        except ValueError:
            self.property_value = -1
        try:
            self.interest_rate = float(fields["interest_rate"])
        except ValueError:
            self.interest_rate = -1
        
        self.applicants = [Applicant(fields["applicant_age"], [fields["applicant_race-1"],fields["applicant_race-2"],fields["applicant_race-3"],fields["applicant_race-4"],fields["applicant_race-5"]])]
        if fields["co-applicant_age"] != '9999':
            self.applicants += [Applicant(fields["co-applicant_age"], [fields["co-applicant_race-1"],fields["co-applicant_race-2"],fields["co-applicant_race-3"],fields["co-applicant_race-4"],fields["co-applicant_race-5"]])]
    
    def __str__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"  
    def __repr__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>" 
    
    def yearly_amounts(self, yearly_payment):
        assert self.interest_rate>0 and self.loan_amount>0
        amt = self.loan_amount

        while amt > 0:
            yield amt
            amt+=self.interest_rate*amt/100
            amt-=yearly_payment
    
class Bank:
    def __init__(self, bank):
        self.bank = bank
        with open("banks.json") as f:
            banks=json.load(f)
        b_in_banks=False
        for b in banks:
            if b["name"]==self.bank:
                b_in_banks=True
                lei=b["lei"]
        assert b_in_banks==True
        self.lei = lei
        
        with ZipFile('wi.zip') as zf:
            with zf.open("wi.csv", "r") as f:
                tio = TextIOWrapper(f)
                dr=csv.DictReader(tio)
        
                self.loans = []
                for row in dr: 
                    if row["lei"] == self.lei:
                        self.loans.append(Loan(fields=row))
                        
    def __getitem__(self, lookup):
        return self.loans[lookup]
    
    def __len__(self):
        return len(self.loans)
        
        
            
        
                    
        
        
        
        
    
