# project: p4
# submitter: hseverson4
# partner: none
# hours: 12


# data source: https://www.kaggle.com/datasets/mathchi/hitters-baseball-data

import pandas as pd
from flask import Flask, request, jsonify, Response
import csv
import matplotlib.pyplot as plt
import matplotlib
import time
from io import StringIO, BytesIO
import re

matplotlib.use('Agg')

app = Flask("my app")
df = pd.read_csv("main.csv")

home_visits = 0
A_visits = 0
B_visits = 0

@app.route('/')
def home():
    global home_visits
    global A_visits
    global B_visits
    
    home_visits += 1
    
    with open("index.html") as f:
        html = f.read()

    if home_visits <= 10:
        if home_visits % 2 == 1: #homepage A (light-blue background)
            html = html.replace("donate.html","donate.html?from=A")
            html = "<body style='background-color:lightblue'>" + html + "</body>"
        
        else: #homepage B (pink background)
            html = html.replace("donate.html","donate.html?from=B")
            html = "<body style='background-color:pink'></p>" + html + "</body>"
            
    else:
        if A_visits >= B_visits:
            html = html.replace("donate.html","donate.html?from=A")
            html = "<body style='background-color:lightblue'>" + html + "</body>"
            
        else:
            assert A_visits < B_visits
            html = html.replace("donate.html","donate.html?from=B")
            html = "<body style='background-color:pink'></p>" + html + "</body>"
    
    html += """<h3>Dashboard</h3>
    <h4>At-Bats (CDF)</h4>
    <img src="plot1.svg">
    <h4>Career Batting Average vs Career At-Bats</h4>
    <img src="plot2.svg">
    <h4>Career Batting Average vs Career At-Bats</h4>
    <img src="plot2.svg?cmap=CHmRun">"""
    
    return html

@app.route("/plot1.svg")
def gen_svg1():
    fig, ax = plt.subplots(figsize=(6,4))
    
    atbat = pd.Series(sorted(df["AtBat"].to_list()))
    rev = pd.Series(100*(atbat.index+1)/len(atbat), index=atbat.values)
    rev.plot.line(ax=ax, ylim=(0,100), drawstyle="steps-post")
    ax.set_xlabel("At-Bats")
    ax.set_ylabel("% Obs Less Than")
    
    f = StringIO() 
    plt.tight_layout()
    fig.savefig(f, format="svg")
    plt.close()
    
    svg = f.getvalue()
    
    hdr = {"Content-Type": "image/svg+xml"}
    return Response(svg, headers=hdr)

@app.route("/plot2.svg")
def gen_svg2():
    fig, ax = plt.subplots(figsize=(6,4))
    
    try:
        cmap = request.args["cmap"]
    except KeyError:
        cmap = None
    
    hits = df["CHits"]
    atbats = df["CAtBat"]
    batting_avg = (hits/atbats).to_list()
    df["B_Avg"] = batting_avg
    s = pd.DataFrame(batting_avg, atbats.tolist())
    
    df.plot.scatter(ax=ax, x="CAtBat",y="B_Avg", c=cmap, cmap="jet")
    ax.set_xlabel("Career At-Bats")
    ax.set_ylabel("Career Batting Avg")
    
    #atbat = pd.Series(sorted(df["AtBat"].to_list()))
    #rev = pd.Series(100*(atbat.index+1)/len(atbat), index=atbat.values)
    #rev.plot.line(ax=ax, ylim=(0,100), drawstyle="steps-post")
    #ax.set_xlabel("At-Bats")
    #ax.set_ylabel("% Obs Less Than")
    
    f = StringIO() 
    plt.tight_layout()
    fig.savefig(f, format="svg")
    plt.close()
    
    svg = f.getvalue()
    
    hdr = {"Content-Type": "image/svg+xml"}
    return Response(svg, headers=hdr)

num_subscribed = 0

@app.route('/email', methods=["POST"])
def email():
    global num_subscribed
    email = str(request.data, "utf-8")
    if re.match(r"\w+@\w+\.\w+", email): # 1
        num_subscribed += 1
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + "\n") # 2
        return jsonify(f"thanks, you're subscriber number {num_subscribed}!")
    return jsonify("Invalid email address.") # 3


@app.route("/browse.html")
def show_table():
    html = "<h1>Browse baseball salary data</h1>" + df.to_html()
    return html

@app.route("/donate.html")
def donate():
    global A_visits
    global B_visits
    
    with open("donate.html") as f:
        html = f.read()
    
    try:
        key = request.args["from"]
        if key == "A":
            A_visits +=1
        if key == "B":
            B_visits +=1
    except KeyError:
        pass
    
    return html

last_visits = {}

@app.route("/browse.json")
def show_json_table():
    global last_visits
    
    ip = request.remote_addr
    try:
        last_visit = last_visits[ip]
    except KeyError:
        last_visit = 0
        
    if time.time() - last_visit >= 60:
        last_visits[ip] = time.time()
        msg = "Browse baseball salary data"
        data = df.to_dict()
        return jsonify(message=msg, data=data)
        
    else:
        msg = "too many requests, come back later"
        return Response(msg, status=429, headers={"Retry-After": 60})
    
    




if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, threaded=False) # don't change this line!

# NOTE: app.run never returns (it runs for ever, unless you kill the process)
# Thus, don't define any functions after the app.run call, because it will
# never get that far.


