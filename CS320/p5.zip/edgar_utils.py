import re
from bisect import bisect
import pandas as pd
import netaddr


ips = pd.read_csv("ip2location.csv")

def lookup_region(ip):
    global ips
    numerical_ip = re.sub(r"[a-zA-Z]", r"0", ip)
    int_ip = int(netaddr.IPAddress(numerical_ip))
    idx = bisect((ips["low"].values), int_ip) - 1
    return ips.loc[idx]['region']


class Filing:
    def __init__(self, html):
        self.dates = re.findall(r"19\d{2}-\d{2}-\d{2}|20\d{2}-\d{2}-\d{2}", html)
        
        try:
            self.sic = int(re.findall(r"SIC=[^\d]*(\d+)", html)[0])
        except IndexError: 
            self.sic = None
        
        self.addresses = []
        for addr_html in re.findall(r'<div class="mailer">([\s\S]+?)</div>', html):
            lines = []
            for line in re.findall(r'<span class="mailerAddress">([\s\S]+?)</span>', addr_html):
                lines.append(line.strip())
            if len(lines) > 0:
                self.addresses.append('\n'.join(lines))

    def state(self):
        for address in self.addresses:
            abbrs = re.findall(r"([A-Z]{2}) \d{5}", address)
            if len(abbrs) > 0:
                return abbrs[0]
        
        return None
        
        
        
        
        